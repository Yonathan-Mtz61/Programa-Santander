Dentro de mi carpeta se encuentran varios archivos de programacion...
Los cuales contienen distintos programas de filtrado de datos (Codigo) y el final que es donde se visualizaran los datos
que es el programa de interfaz grafica (PROYECTO-01-MARTINEZ MEDRANO-YONATHAN ANDONI) le puse este nombre ya que es el programa como tal...


Dentro de la interfaz grafica se encontrara un login de usuario, si no tiene cuenta podra crear una, 
o si no podra usar la cuenta de administrados la cual es "123" para el correo y "123" para la contraseña.

Ya dentro del programa como tal se encontrara un Listbox el cual podra seleccionar que opcion quiere ver de Life Store
y con el boton Buscar podra visualizarlo en la parte inferior los resultados del programa de filtrado de datos (main).

En el ultimo punto que son las conclusiones se podra observar los datos mas simplificados de todo este proceso de filtrado y analisis de datos.

