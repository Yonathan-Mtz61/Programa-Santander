from tkinter import *
from tkinter import ttk
import tkinter as tk
from tkinter import messagebox
from Codigo import *

ventana=tk.Tk()
ventana.geometry("350x300")
ventana.title("LifeStore - Login")
ventana.resizable(0,0)

global correos
global contraseñas
global combo
global lista_desplegable

correos=['123']
contraseñas=['123']
opciones=['Productos más vendidos y productos rezagados',
          'Top 50 productos con mas ventas',
          'Top 100 productos con mas busquedas',
          'Por categoria, Top 50 productos con menos ventas',
          'Por categoria, Top 100 productos con menos busquedas',
          'Productos por reseña en el servicio',
          'Top 20 productos con mejores reseñas',
          'Top 20 productos con peores reseñas',
          'Total de ingresos y ventas promedio mensuales,total anual y meses con más ventas al año',
          'Conclusion de los resultados en base a los datos'] 


def Entrar ():

    def main():    

        texto_solicitado.delete("1.0","end")
        
        if lista_desplegable.get() == 'Productos más vendidos y productos rezagados':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)
            
            texto_solicitado.insert(tk.INSERT,"Top 50 productos con mas ventas\n\n")
            for i in range(0,len(lista_top50_mayores_ventas),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top50_mayores_ventas[i])+"\n")

            texto_solicitado.insert(tk.INSERT,"\nTop 100 productos con mas busquedas\n\n")
            for i in range(0,len(lista_top100_mayores_buscados),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top100_mayores_buscados[i])+"\n")

            texto_solicitado.insert(tk.INSERT,"\nPor categoria, Top 50 productos con menos ventas\n\n")
            for i in range(0,len(Pcategoria_50productos_menos_ventas),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(Pcategoria_50productos_menos_ventas[i])+"\n")

            texto_solicitado.insert(tk.INSERT,"\nPor categoria, Top 100 productos con menos busquedas\n\n")
            for i in range(0,len(lista_top100_menos_buscados),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top100_menos_buscados[i])+"\n")
            

        elif lista_desplegable.get() == 'Top 50 productos con mas ventas':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)
                        
            texto_solicitado.insert(tk.INSERT,"Top 50 productos con mas ventas\n\n")
            for i in range(0,len(lista_top50_mayores_ventas),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top50_mayores_ventas[i])+"\n")

        elif lista_desplegable.get() == 'Top 100 productos con mas busquedas':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Top 100 productos con mas busquedas\n\n")
            for i in range(0,len(lista_top100_mayores_buscados),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top100_mayores_buscados[i])+"\n")

        elif lista_desplegable.get() == 'Por categoria, Top 50 productos con menos ventas':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Por categoria, Top 50 productos con menos ventas\n\n")
            for i in range(0,len(Pcategoria_50productos_menos_ventas),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(Pcategoria_50productos_menos_ventas[i])+"\n")

        elif lista_desplegable.get() == 'Por categoria, Top 100 productos con menos busquedas':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Por categoria, Top 100 productos con menos busquedas\n\n")
            for i in range(0,len(lista_top100_menos_buscados),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top100_menos_buscados[i])+"\n")

        elif lista_desplegable.get() == 'Productos por reseña en el servicio':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Top 20 productos con mejores reseñas\n\n")
            for i in range(0,len(lista_20_productos_mejor_reseñas),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_20_productos_mejor_reseñas[i])+"\n")

            texto_solicitado.insert(tk.INSERT,"\nTop 20 productos con peores reseñas\n\n")
            for i in range(0,len(lista_top20_productos_peor_reseña),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top20_productos_peor_reseña[i])+"\n")

        elif lista_desplegable.get() == 'Top 20 productos con mejores reseñas':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Top 20 productos con mejores reseñas\n\n")
            for i in range(0,len(lista_20_productos_mejor_reseñas),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_20_productos_mejor_reseñas[i])+"\n")

        elif lista_desplegable.get() == 'Top 20 productos con peores reseñas':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Top 20 productos con peores reseñas\n\n")
            for i in range(0,len(lista_top20_productos_peor_reseña),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_top20_productos_peor_reseña[i])+"\n")

        
        elif lista_desplegable.get() == 'Total de ingresos y ventas promedio mensuales,total anual y meses con más ventas al año':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Total de ingresos y ventas promedio mensuales,total anual y meses con más ventas al año\n\n")
            texto_solicitado.insert(tk.INSERT,"El total de ventas es: "+str(total_ventas)+" $\n\n")
            texto_solicitado.insert(tk.INSERT,"El promedio  mensual de rembolsos es: "+str(round(promedio_rembolsos_total,3))+" $\n\n")
            texto_solicitado.insert(tk.INSERT,"El promedio de ventas cada mes se muestra en la siguiente lista: \n\n")
            
            for i in range(0,len(meses_ventas_promedio_final),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(meses_ventas_promedio_final[i])+"\n")

            texto_solicitado.insert(tk.INSERT,"\nLos meses con mas ventas y cuantas ventas tuvieron se muestran en la siguiente lista: \n\n")

            for i in range(0,len(meses_mas_ventas_orden),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(meses_mas_ventas_orden[i])+"\n")

        elif lista_desplegable.get() == 'Conclusion de los resultados en base a los datos':
            scroll.pack(side=tk.RIGHT,fill=tk.Y)
            texto_solicitado.pack(side=tk.LEFT,fill=tk.Y)
            
            scroll.config(command=texto_solicitado.yview)
            texto_solicitado.config(yscrollcommand=scroll.set)

            texto_solicitado.insert(tk.INSERT,"Conclusion de los resultados en base a los datos\n")
            texto_solicitado.insert(tk.INSERT,"\nPor lo que la prioridad son los primeros lugares en Life Store segun las ventas que se hicieron\n\n")
            for i in range(0,len(lista_conclusion_completa),1):
                texto_solicitado.insert(tk.INSERT,str(i+1)+"° "+str(lista_conclusion_completa[i])+"\n")

            texto_solicitado.insert(tk.INSERT,"\nPodria decirse que en el analisis de los datos de busquedas, reseñas, y ventas de los productos")
            texto_solicitado.insert(tk.INSERT,"\nen Life Store los filtre lo mas posible para que pudiera ser mas entendible tanto por categorias como")
            texto_solicitado.insert(tk.INSERT,"\npor meses de mas ingreso asi como los puntos que pedia este tipo de analisis...")


            
                
    for i in range(0,len(correos),1):
        if correo_entrada.get() == correos[i]:
            for j in range(0,len(contraseñas),1):
                if contraseña_entrada.get() == contraseñas[i]:
                    ventana_informacion=Toplevel()
                    ventana_informacion.geometry("850x700")
                    ventana_informacion.title("LifeStore - Informacion")
                    ventana_informacion.resizable(0,0)

                    frame=Frame(ventana_informacion,width=830,height=568,bg='gray')
                    frame.place(x=10,y=120)            
                   
                    lista_desplegable=StringVar()
                    
                    Label(ventana_informacion,text="Life Store",font=("Comic Sans MS",23)).place(x=65,y=10)
                    Label(ventana_informacion,text="¿Que te gustaria saber de Life Store?",font=("Comic Sans MS",15)).place(x=280,y=23)
                    Label(ventana_informacion,text="Seleccione una opcion: ",font=("Comic Sans MS",12)).place(x=15,y=70)
                    
                    lista_desplegable = ttk.Combobox(ventana_informacion,width=80,value=opciones,state='readonly')
                    lista_desplegable.place(x=185,y=75)
                    lista_desplegable.current(0)

                    scroll=tk.Scrollbar(frame)
                    texto_solicitado=tk.Text(frame,width=101,height=37)
                    
                    Button(ventana_informacion,text=("Buscar"),width=10,font=("Comic Sans MS",15),command=main).place(x=705,y=60)

                                       
                    
                    return None
            messagebox.showerror("Error de contraseña","Intente de nuevo!")
            return None
    messagebox.showerror("Error de correo","Intente de nuevo!")

def Registro ():

    def guardar_datos ():
        for i in range(0,len(correo.get()),1):
            if correo.get()[i]=='@':
                if correo.get()[i:] == '@gmail.com' or correo.get()[i:] == '@hotmail.com' or correo.get()[i:] == '@outlook.com':
                    if len(contraseña.get())!= 0:
                        correos.append(correo.get())
                        contraseñas.append(contraseña.get())
                        ventana_registro.destroy()
                        return None
                    messagebox.showerror("Error de contraseña","Intente de nuevo! Ingresa una contraseña")
                    return None
                messagebox.showerror("Error de correo","Intente de nuevo! recuerda que el correo debe llevar una direccion!")
                return None
        messagebox.showerror("Error de correo","Intente de nuevo! recuerda que el correo debe llevar '@' !!!")
        return None
    
    ventana_registro=Toplevel()
    ventana_registro.geometry("350x200")
    ventana_registro.title("LifeStore - Registro")
    ventana_registro.resizable(0,0)
    
    Label(ventana_registro,text="Life-Store",font=("Comic Sans MS",23)).place(x=90,y=10)
    Label(ventana_registro,text="-Registro-",font=("Comic Sans MS",15)).place(x=120,y=50)
    Label(ventana_registro,text="Correo: ",font=("Comic Sans MS",12)).place(x=48,y=80)
    Label(ventana_registro,text="Contraseña: ",font=("Comic Sans MS",12)).place(x=15,y=110)


    correo=StringVar()
    Entry(ventana_registro,width=35,textvariable=correo).place(x=115,y=87)
    
    contraseña=StringVar()
    Entry(ventana_registro,width=35,textvariable=contraseña).place(x=115,y=117)

    
    Button(ventana_registro,width=17,text="Ingresar",font=("Comic Sans MS",12),command=guardar_datos).place(x=130,y=147)


#Etiquetas---------------------------------------------------------------------------

Label(text="Life-Store",font=("Comic Sans MS",23)).place(x=90,y=10)
Label(text="Correo: ",font=("Comic Sans MS",12)).place(x=48,y=80)
Label(text="Contraseña: ",font=("Comic Sans MS",12)).place(x=15,y=110)
Label(text="¿No tienes cuenta?",font=("Comic Sans MS",12)).place(x=100,y=200)


#Entradas----------------------------------------------------------------------------
correo_entrada=StringVar()
Entry(ventana,textvariable=correo_entrada,width=35).place(x=115,y=87)
contraseña_entrada=StringVar()
Entry(ventana,textvariable=contraseña_entrada,width=35).place(x=115,y=117)


#Botones-----------------------------------------------------------------------------
boton_entrar=Button(ventana,width=17,text=("Ingresar"),font=("Comic Sans MS",12),command=Entrar).place(x=132,y=147)
boton_registarse=Button(ventana,width=17,text=("Registrate"),font=("Comic Sans MS",12),command=Registro).place(x=80,y=230)


ventana.mainloop()

