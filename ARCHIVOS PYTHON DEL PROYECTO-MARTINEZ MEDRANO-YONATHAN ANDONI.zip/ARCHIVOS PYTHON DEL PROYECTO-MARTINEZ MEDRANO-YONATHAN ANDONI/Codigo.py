from lifestore_file import*


"""
This is the LifeStore_SalesList data:

lifestore_searches = [id_search, id product]
lifestore_sales = [id_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore_products = [id_product, name, price, category, stock]
"""


#Productos más vendidos y productos rezagados:

"""1.-Generar un listado de los 50 productos con mayores ventas y uno con
      los 100 productos con mayor búsquedas.
   2.-Por categoría, generar un listado con los 50 productos con menores
      ventas y uno con los 100 productos con menores búsquedas.
"""

"""
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("-------------------------------------------------------------PRODUCTOS MAS VENDIDOS Y PRODUCTOS REZAGADOS--------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("------------------------------------------------------------Listado de los 50 productos con mayores ventas-------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
"""
lista_productos_sales=[]
for i in range(0,len(lifestore_sales),1):
    if lifestore_sales[i][4] == 0:
        lista_productos_sales.append(lifestore_sales[i][1])

lista_productos_sales_Norepetidos=[]
for i in range(0,len(lista_productos_sales),1):
    if lista_productos_sales[i]!=lista_productos_sales[i-1]:
        lista_productos_sales_Norepetidos.append(lista_productos_sales[i])
        
lista_productos_sales_conteo=[]
for i in range(0,len(lista_productos_sales_Norepetidos),1):
    lista_productos_sales_conteo.append(lista_productos_sales.count(lista_productos_sales_Norepetidos[i]))

lista_Norepetidos_sales_conteo=[]
for i in range(0,len(lista_productos_sales_Norepetidos),1):
    lista_Norepetidos_sales_conteo.append([lista_productos_sales_Norepetidos[i],lista_productos_sales_conteo[i]])

lista_mayor_a_sales=[]
for i in range(0,len(lista_Norepetidos_sales_conteo),1):
    if lista_Norepetidos_sales_conteo[i][1]>=4:
        lista_mayor_a_sales.append(lista_Norepetidos_sales_conteo[i])


lista_mayor_a_sales.sort(key=lambda x:x[1],reverse=True)

lista_top50_mayores_ventas=[]
for i in range(0,len(lista_mayor_a_sales),1):
    for j in range(0,len(lifestore_products),1):
        if lista_mayor_a_sales[i][0] == lifestore_products[j][0]:
            lista_top50_mayores_ventas.append(["El producto es: "+str(lifestore_products[j][1])+" y tuvo: "+str(lista_mayor_a_sales[i][1])+" ventas"])
"""
print()
print(lista_top50_mayores_ventas)
print()

print(lista_mayor_a)
print(lista_productos_sales)
print(lista_productos_sales_Norepetidos)
print(lista_productos_sales_conteo)
print(lista_Norepetidos_conteo)





print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print()
"-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------"


print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("-----------------------------------------------------------Listado de los 100 productos con mayor búsquedos------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
"""
lista_productos_searches=[]
for i in range(0,len(lifestore_searches),1):
    lista_productos_searches.append(lifestore_searches[i][1])

lista_productos_searches_Norepetidos=[]
for i in range(0,len(lista_productos_searches),1):
    if lista_productos_searches [i] != lista_productos_searches[i-1]:
        lista_productos_searches_Norepetidos.append(lista_productos_searches [i])

lista_productos_searches_conteo=[]
for i in range(0,len(lista_productos_searches_Norepetidos),1):
    lista_productos_searches_conteo.append(lista_productos_searches.count(lista_productos_searches_Norepetidos[i]))

lista_Norepetidos_searches_conteo=[]
for i in range(0,len(lista_productos_searches_Norepetidos),1):
    lista_Norepetidos_searches_conteo.append([lista_productos_searches_Norepetidos[i],lista_productos_searches_conteo[i]])

lista_mayor_a_searches=[]
for i in range(0,len(lista_Norepetidos_searches_conteo),1):
    if lista_Norepetidos_searches_conteo[i][1]>=4:
        lista_mayor_a_searches.append(lista_Norepetidos_searches_conteo[i])

lista_mayor_a_searches.sort(key=lambda x:x[1],reverse=True)

lista_top100_mayores_buscados=[]
for i in range(0,len(lista_mayor_a_searches),1):
    for j in range(0,len(lifestore_products),1):
        if lista_mayor_a_searches[i][0] == lifestore_products[j][0]:
            lista_top100_mayores_buscados.append(["El producto es: "+str(lifestore_products[j][1])+" Y se busco: "+str(lista_mayor_a_searches[i][1])+" veces"])
"""
print()
print(lista_top100_mayores_buscados)

print(lista_productos_searches)
print(lista_productos_searches_Norepetidos)
print(lista_productos_searches_conteo)
print(lista_Norepetidos_searches_conteo)



print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")


print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("------------------------------------------------------------Por categoria, 50 productos con menos ventas-------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
"""
lista_productos_menos_ventas=[]
for i in range(0,len(lifestore_sales),1):
    if lifestore_sales[i][4] == 0:
        lista_productos_menos_ventas.append(lifestore_sales[i][1])
        
lista_productos_menos_ventas_Norepetidos=[]
for i in range(0,len(lista_productos_menos_ventas),1):
    if lista_productos_menos_ventas[i] != lista_productos_menos_ventas[i-1]:
       lista_productos_menos_ventas_Norepetidos.append(lista_productos_menos_ventas[i])

lista_productos_menos_ventas_conteo=[]
for i in range(0,len(lista_productos_menos_ventas_Norepetidos),1):
    lista_productos_menos_ventas_conteo.append(lista_productos_menos_ventas.count(lista_productos_menos_ventas_Norepetidos[i]))
    
lista_Norepetidos_menos_ventas=[]
for i in range(0,len(lista_productos_menos_ventas_Norepetidos),1):
    lista_Norepetidos_menos_ventas.append([lista_productos_menos_ventas_Norepetidos[i],lista_productos_menos_ventas_conteo[i],lifestore_products[lista_productos_menos_ventas_Norepetidos[i]][3]])

lista_menor_a_menos_ventas=[]
for i in range(0,len(lista_Norepetidos_menos_ventas),1):
    if lista_Norepetidos_menos_ventas[i][1]<=5:
        lista_menor_a_menos_ventas.append(lista_Norepetidos_menos_ventas[i])

lista_menor_a_menos_ventas.sort(key=lambda x:x[2],reverse=False)

Pcategoria_50productos_menos_ventas=[]
for i in range(0,len(lista_menor_a_menos_ventas),1):
    for j in range(0,len(lifestore_products),1):
        if lista_menor_a_menos_ventas[i][0] == lifestore_products[j][0]:
            Pcategoria_50productos_menos_ventas.append(["El producto es: "+str(lifestore_products[j][1])+" Y se vendio: "+str(lista_menor_a_menos_ventas[i][1])+" veces, y su categoria es: "+str(lista_menor_a_menos_ventas[i][2])])
"""
print()
print(Pcategoria_50productos_menos_ventas)

print(lista_productos_menos_ventas)
print(lista_productos_menos_ventas_Norepetidos)
print(lista_productos_menos_ventas_conteo)
print(lista_Norepetidos_menos_ventas)
print(lista_menor_a_menos_ventas)



print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")

print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("----------------------------------------------------------Por categoria, 100 productos con menos busquedas-------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
"""
lista_mayor_a_searches=[]
for i in range(0,len(lista_Norepetidos_searches_conteo),1):
    if lista_Norepetidos_searches_conteo[i][1]<=10:
        lista_mayor_a_searches.append(lista_Norepetidos_searches_conteo[i])
        
lista_mayor_a_searches.sort(key=lambda x:x[1],reverse=False)

lista_top100_menos_buscados=[]
for i in range(0,len(lista_mayor_a_searches),1):
    for j in range(0,len(lifestore_products),1):
        if lista_mayor_a_searches[i][0] == lifestore_products[j][0]:
            lista_top100_menos_buscados.append(["El producto es: "+str(lifestore_products[j][1])+" Y se busco: "+str(lista_mayor_a_searches[i][1])+" veces"])
            
"""print(lista_mayor_a_searches)
print()
print(lista_top100_menos_buscados)


print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print()





#Productos por reseña en el servicio
""""""Mostrar dos listados de 20 productos cada una, un listado para
productos con las mejores reseñas y otro para las peores, considerando
los productos con devolución. 
""""""

print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("------------------------------------------------------------------PRODUCTOS POR RESEÑAS DEL SERVICIO-------------------------------------------------------------------")
print("---------------------------------------------------------------------20 Productos con mejor reseña---------------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print()
"""

lista_mejor_reseña_sales=[]
for i in range(0,len(lifestore_sales),1):
    if lifestore_sales[i][2] >=5 and lifestore_sales[i][4] ==0:
        lista_mejor_reseña_sales.append(lifestore_sales[i][1])
        
lista_mejor_reseña_sales_Norepetidos=[]
for i in range(0,len(lista_mejor_reseña_sales),1):
    if lista_mejor_reseña_sales[i] != lista_mejor_reseña_sales[i-1]:
        lista_mejor_reseña_sales_Norepetidos.append(lista_mejor_reseña_sales[i])
    
lista_mejor_reseña_sales_conteo=[]
for i in range(0,len(lista_mejor_reseña_sales_Norepetidos),1):
    lista_mejor_reseña_sales_conteo.append(lista_mejor_reseña_sales.count(lista_mejor_reseña_sales_Norepetidos[i]))

lista_mejor_reseñas_Sales_categorias=[]
for i in range(0,len(lista_mejor_reseña_sales_Norepetidos),1):
    lista_mejor_reseñas_Sales_categorias.append(lifestore_products[lista_mejor_reseña_sales_Norepetidos[i]][3])

lista_mejor_reseña_Sales_orden=[]
for i in range(0,len(lista_mejor_reseña_sales_Norepetidos),1):
    lista_mejor_reseña_Sales_orden.append([lista_mejor_reseña_sales_Norepetidos[i],lista_mejor_reseña_sales_conteo[i],lista_mejor_reseñas_Sales_categorias[i]])

lista_mejor_reseña_Sales_orden.sort(key=lambda x:x[1],reverse=True)

lista_20_productos_mejor_reseñas=[]
for i in range(0,20,1):
    for j in range(0,len(lifestore_products),1):
        if lista_mejor_reseña_Sales_orden[i][0] == lifestore_products[j][0]:
            lista_20_productos_mejor_reseñas.append(["El producto: "+str(lifestore_products[j][1])+" tuvo "+str(lista_mejor_reseña_Sales_orden[i][1])+" reseñas de '5' y se encuentra en la categoria de: "+str(lista_mejor_reseña_Sales_orden[i][2])])

"""
print(lista_20_productos_mejor_reseñas)

print(lista_mejor_reseña_sales)
print(lista_mejor_reseña_sales_Norepetidos)
print(lista_mejor_reseña_sales_conteo)
print(lista_mejor_reseñas_Sales_categorias)
print(lista_mejor_reseña_Sales_orden)

print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")

      

print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("---------------------------------------------------------------------20 Productos con peor reseña---------------------------------------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print()
"""
lista_peor_reseña_sales=[]
lista_peor_reseña_sales_reseña=[]
for i in range(0,len(lifestore_sales),1):
    if lifestore_sales[i][2] <=3 or lifestore_sales[i][4] == 1:
        lista_peor_reseña_sales.append(lifestore_sales[i][1])
        lista_peor_reseña_sales_reseña.append(lifestore_sales[i][2])

lista_peor_reseña_sales_categoria=[]
for i in range(0,len(lista_peor_reseña_sales),1):
    lista_peor_reseña_sales_categoria.append(lifestore_products[lista_peor_reseña_sales[i]][3])

lista_peor_reseña_orden=[]
for i in range(0,len(lista_peor_reseña_sales),1):
    lista_peor_reseña_orden.append([lista_peor_reseña_sales[i],lista_peor_reseña_sales_reseña[i],lista_peor_reseña_sales_categoria[i]])
    
lista_peor_reseña_orden.sort(key=lambda x:x[1],reverse=True)

lista_top20_productos_peor_reseña=[]
for i in range(0,len(lista_peor_reseña_orden),1):
    for j in range(0,len(lifestore_products),1):
        if lista_peor_reseña_orden[i][0] == lifestore_products[j][0]:
            lista_top20_productos_peor_reseña.append("El producto es: "+str(lifestore_products[j][1])+" Y tuvo: "+str(lista_peor_reseña_orden[i][1])+" reseñas menores o iguales a '3' y se encuentra en la categoria de: "+str(lista_peor_reseña_orden[i][2]))
"""
print(lista_top20_productos_peor_reseña)

print(lista_peor_reseña_sales)
print(lista_peor_reseña_sales_reseña)
print(lista_peor_reseña_sales_categoria)
print(lista_peor_reseña_orden)

print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")




print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print("---------------------------------------Total de ingresos y ventas promedio mensuales, total anual y meses con mas ventas en el año-------------------------------------")
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")
print()
"""

total_ingresos_sales_ventas=[]
total_ingresos_sales_rembolsos=[]
total_rembolsos=0
total_ventas=0
meses_mas_ventas=[]
meses_mas_ventas_Norepetidos=[]
meses_mas_ventas_conteo=[]

for i in range(0,len(lifestore_sales),1):
    if lifestore_sales[i][4]==0:
        total_ingresos_sales_ventas.append([lifestore_sales[i][1],lifestore_products[lifestore_sales[i][1]][2]])
        total_ventas+=lifestore_products[lifestore_sales[i][1]][2]
        meses_mas_ventas.append(lifestore_sales[i][3][3:5])
    else:
        total_ingresos_sales_rembolsos.append([lifestore_sales[i][1],lifestore_products[lifestore_sales[i][1]][2]])
        total_rembolsos+=lifestore_products[lifestore_sales[i][1]][2]

    
meses_mas_ventas.sort()

for i in range(0,len(meses_mas_ventas),1):
    if meses_mas_ventas[i]!= meses_mas_ventas[i-1]:
        meses_mas_ventas_Norepetidos.append(meses_mas_ventas[i])
        

for i in range(0,len(meses_mas_ventas_Norepetidos),1):
    meses_mas_ventas_conteo.append(meses_mas_ventas.count(meses_mas_ventas_Norepetidos[i]))


meses_nombre=[]
for i in range(0,len(meses_mas_ventas_Norepetidos),1):
    if meses_mas_ventas_Norepetidos[i]=='01':
        meses_nombre.append('Enero')
    elif meses_mas_ventas_Norepetidos[i]=='02':
        meses_nombre.append('Febrero')
    elif meses_mas_ventas_Norepetidos[i]=='03':
        meses_nombre.append('Marzo')
    elif meses_mas_ventas_Norepetidos[i]=='04':
        meses_nombre.append('Abril')
    elif meses_mas_ventas_Norepetidos[i]=='05':
        meses_nombre.append('Mayo')
    elif meses_mas_ventas_Norepetidos[i]=='06':
        meses_nombre.append('Junio')
    elif meses_mas_ventas_Norepetidos[i]=='07':
        meses_nombre.append('Julio')
    elif meses_mas_ventas_Norepetidos[i]=='08':
        meses_nombre.append('Agosto')
    elif meses_mas_ventas_Norepetidos[i]=='09':
        meses_nombre.append('Septiembre')
    elif meses_mas_ventas_Norepetidos[i]=='10':
        meses_nombre.append('Octubre')
    elif meses_mas_ventas_Norepetidos[i]=='11':
        meses_nombre.append('Noviembre')
    elif meses_mas_ventas_Norepetidos[i]=='12':
        meses_nombre.append('Diciembre')

meses_mas_ventas_orden=[]
for i in range(0,len(meses_nombre),1):
    meses_mas_ventas_orden.append(['El mes de: '+meses_nombre[i],meses_mas_ventas_conteo[i],'se vendio'])

promedio_rembolsos_total=total_rembolsos / len(total_ingresos_sales_rembolsos)


meses_ventas_promedio=[]
for i in range(0,len(meses_mas_ventas_Norepetidos),1):
    meses_ventas_promedio.append(str(round((total_ventas*meses_mas_ventas_conteo[i])/len(total_ingresos_sales_ventas),3)))


meses_nombres_ventas=[]
for i in range(0,len(meses_mas_ventas_Norepetidos),1):
    
    if meses_mas_ventas_Norepetidos[i]=='01':
        meses_nombres_ventas.append('Enero')
    elif meses_mas_ventas_Norepetidos[i]=='02':
        meses_nombres_ventas.append('Febrero')
    elif meses_mas_ventas_Norepetidos[i]=='03':
        meses_nombres_ventas.append('Marzo')
    elif meses_mas_ventas_Norepetidos[i]=='04':
        meses_nombres_ventas.append('Abril')
    elif meses_mas_ventas_Norepetidos[i]=='05':
        meses_nombres_ventas.append('Mayo')
    elif meses_mas_ventas_Norepetidos[i]=='06':
        meses_nombres_ventas.append('Junio')
    elif meses_mas_ventas_Norepetidos[i]=='07':
        meses_nombres_ventas.append('Julio')
    elif meses_mas_ventas_Norepetidos[i]=='08':
        meses_nombres_ventas.append('Agosto')
    elif meses_mas_ventas_Norepetidos[i]=='09':
        meses_nombres_ventas.append('Septiembre')
    elif meses_mas_ventas_Norepetidos[i]=='10':
        meses_nombres_ventas.append('Octubre')
    elif meses_mas_ventas_Norepetidos[i]=='11':
        meses_nombres_ventas.append('Noviembre')
    elif meses_mas_ventas_Norepetidos[i]=='12':
        meses_nombres_ventas.append('Diciembre')

meses_ventas_promedio_final=[]
for i in range(0,len(meses_nombres_ventas),1):
    meses_ventas_promedio_final.append(["El mes: "+str(meses_nombres_ventas[i])+" se vendio: "+str(meses_ventas_promedio[i])+" $"])


    
"""
print(total_ventas)
print(meses_mas_ventas_Norepetidos)
print(meses_mas_ventas_conteo)
print(meses_ventas_promedio)
print(len(total_ingresos_sales_ventas))
print(meses_nombres_ventas)
print(meses_ventas_promedio_final)"""

"""
meses_mas_ventas_orden.sort(key=lambda x:x[1],reverse=True)

print("El total de rembolsos es: "+str(total_rembolsos)+" $")
print("El total de ventas es: "+str(total_ventas)+" $")

promedio_rembolsos_total=total_rembolsos / len(total_ingresos_sales_rembolsos)
print("El promedio total de rembolsos es: "+str(round(promedio_rembolsos_total,3))+" $")

print("El total anual es el mismo que el de las ventas totales: "+str(total_ventas)+" $")

print()
print("Los meses con mas ventas y cuantas ventas tuvieron se muestran en la siguiente lista: ")
print()
print(meses_mas_ventas_orden)

print(meses_mas_ventas_Norepetidos)
print(meses_mas_ventas_conteo)
print(meses_nombre)
print(total_ingresos_sales_ventas)
print(total_ingresos_sales_rembolsos)
print(len(total_ingresos_sales_ventas))
print(len(total_ingresos_sales_rembolsos))
print(len(lifestore_sales))
print(meses_mas_ventas)
"""


"""
print()
print("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------")

"""





lista_mas_ventas_sales=[]
for i in range(0,len(lifestore_sales),1):
    if lifestore_sales[i][4] == 0:
        lista_mas_ventas_sales.append(lifestore_sales[i][1])

lista_mas_ventas_sales_Norepetidos=[]
for i in range(0,len(lista_mas_ventas_sales),1):
    if lista_mas_ventas_sales[i] != lista_mas_ventas_sales[i-1]:
        lista_mas_ventas_sales_Norepetidos.append(lista_mas_ventas_sales[i])

lista_mas_ventas_sales_conteo=[]
for i in range(0,len(lista_mas_ventas_sales_Norepetidos),1):
    lista_mas_ventas_sales_conteo.append(lista_mas_ventas_sales.count(lista_mas_ventas_sales_Norepetidos[i]))

lista_mas_ventas_sales_orden=[]
for i in range(0,len(lista_mas_ventas_sales_conteo),1):
    lista_mas_ventas_sales_orden.append([lista_mas_ventas_sales_conteo[i],lifestore_products[lista_mas_ventas_sales_Norepetidos[i]][1],lifestore_products[lista_mas_ventas_sales_Norepetidos[i]][3]])

lista_mas_ventas_sales_orden.sort(key=lambda x:x[0],reverse=True)

categorias_productos=[]
for i in range(0,len(lifestore_products),1):
    categorias_productos.append(lifestore_products[i][3])

categorias_productos_Norepetidos=[]
for i in range(0,len(categorias_productos),1):
    if categorias_productos[i] != categorias_productos[i-1]:
        categorias_productos_Norepetidos.append(categorias_productos[i])

categorias_productos_Norepetidos.sort(key=lambda x:x[2],reverse=True)

productos_vendidos_categorias=[]
for i in range(0,len(categorias_productos_Norepetidos),1):
    conteo=0
    for j in range(0,len(lista_mas_ventas_sales_orden),1):
           if categorias_productos_Norepetidos [i] == lista_mas_ventas_sales_orden[j][2]:
               conteo+=lista_mas_ventas_sales_orden[j][0]
    productos_vendidos_categorias.append(conteo)


prueba=[]
for i in range(0,len(categorias_productos_Norepetidos),1):
    conteo=0
    if lifestore_sales[i][4]==0:
        for j in range(0,len(lifestore_sales),1):
            for k in range(0,len(lifestore_products),1):
                if lifestore_sales[j][1] == lifestore_products[k][0] and lifestore_products[k][3] == categorias_productos_Norepetidos[i]:
                    conteo+=lifestore_products[k][2]
    prueba.append(conteo)


lista_conclusion=[]
for i in range(0,len(productos_vendidos_categorias),1):
    lista_conclusion.append([productos_vendidos_categorias[i],categorias_productos_Norepetidos[i],prueba[i]])

lista_conclusion.sort(key=lambda x:x[2],reverse=True)


lista_conclusion_completa=[]
for i in range(0,len(lista_conclusion),1):
    lista_conclusion_completa.append("La categoria: "+str(lista_conclusion[i][1])+" tuvo: "+str(lista_conclusion[i][0])+" ventas con un total de: "+str(lista_conclusion[i][2])+" $")


#print(lista_conclusion_completa)

"""prueba_precio=[]
for i in range(0,len(prueba),1):
    for j in range(0,len(lifestore_products),1):
        if prueba[i]==lifestore_products[j][0]:
            prueba_precio.append(lifestore_products[j][2])

prueba_precios_total=[]
for i in range(0,len(categorias_productos_Norepetidos),1):
    for j in range(0,len(),1):

print(prueba)
print()
print(prueba_precio)"""



















